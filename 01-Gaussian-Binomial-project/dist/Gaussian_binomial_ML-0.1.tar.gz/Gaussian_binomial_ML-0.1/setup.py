from setuptools import setup

setup(name='Gaussian_binomial_ML',
      version='0.1',
      description='Gaussian distributions',
      packages=['Gaussian_binomial_ML'],
      author='IkraP',
      zip_safe=False)
